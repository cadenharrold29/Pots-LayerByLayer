# Getting a Custom Domain — 100% Free Option Included

Right now your site lives at:
`https://cadenharrold29.github.io/Pots-LayerByLayer/`

That works fine, but a shorter custom domain looks more like a "real" business.
Here are two ways to get one — one is completely free, one costs a few dollars a year.

---

## OPTION A — Totally Free: `potslayerbylayer.is-a.dev`

[is-a.dev](https://is-a.dev) is a free service (used by thousands of student/dev projects)
that gives you a real subdomain — no cost, no credit card, ever.

**Steps:**

1. Go to **github.com/is-a-dev/register** and click **Fork** (top right) to fork it to your account.
2. In your fork, go to the `domains/` folder and click **Add file → Create new file**.
3. Name the file **`potslayerbylayer.json`** (or whatever name you want before `.is-a.dev`).
4. Paste this content in (already filled in for you — just double check the email):

   ```json
   {
     "owner": {
       "username": "Cadenharrold29",
       "email": "CadenHarrold29@gmail.com"
     },
     "records": {
       "CNAME": "cadenharrold29.github.io"
     }
   }
   ```

5. Commit the file, then click **Contribute → Open pull request** to submit it back to
   the main `is-a-dev/register` repo.
6. Wait for it to be merged (usually within a day or two — it's automated + reviewed by bots).
7. Once merged, go to your `Pots-LayerByLayer` repo → **Settings → Pages → Custom domain**,
   and enter `potslayerbylayer.is-a.dev`. Check **Enforce HTTPS** once the green checkmark appears.
8. Rename the `CNAME.example` file in this project to `CNAME` (no extension) so your repo
   remembers the custom domain on future deploys. Its contents should just be:
   ```
   potslayerbylayer.is-a.dev
   ```

Your site is now live at `https://potslayerbylayer.is-a.dev` — for free, forever.

---

## OPTION B — Paid but Classic: a real `.com`

If you'd rather have `potslayerbylayer.com` (or similar), domains typically run
**$10–15/year** through registrars like Namecheap, Porkbun, or Google Domains successor Squarespace Domains.
Avoid GoDaddy's flashy upsells — Porkbun and Namecheap are cheaper and simpler for beginners.

1. Buy the domain from your registrar of choice.
2. In the registrar's DNS settings, add these records (GitHub's official IPs):
   ```
   A     @     185.199.108.153
   A     @     185.199.109.153
   A     @     185.199.110.153
   A     @     185.199.111.153
   CNAME www   cadenharrold29.github.io
   ```
3. In your GitHub repo → **Settings → Pages → Custom domain**, enter your domain and save.
4. Rename `CNAME.example` in this project to `CNAME` with your domain inside, e.g.:
   ```
   potslayerbylayer.com
   ```
5. Wait up to an hour for DNS + HTTPS to activate, then check **Enforce HTTPS**.

---

## Which should you pick?

- **Just starting out / want $0 cost** → Option A (`is-a.dev`)
- **Ready to treat this like a real brand long-term** → Option B (a real `.com`)

Either way, once it's live, update:
- The `og:url` line in `index.html`
- `sitemap.xml` and `robots.txt`
- Your Venmo/social bio links

to point at the new domain instead of the `github.io` one.
