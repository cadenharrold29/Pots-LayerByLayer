# Pots Layer By Layer 🌿

> Missouri FFA Project · 3D Printed Planter Pots

Original 3D-printed planters in Bone White and Olive Green. Designed in Onshape, printed in Sunlu PLA, finished with an airbrushed logo. Every pot includes a custom cork-bottom coaster.

**Live site:** [cadenharrold29.github.io/Pots-LayerByLayer](https://cadenharrold29.github.io/Pots-LayerByLayer/)

## Designs
- **Spike** — $12.99 · Small
- **Weave** — $12.99 · Small
- **Diamond** — $16.99 · Large
- **Cork Coaster** — $1.99 · Add-on

## Payment
Venmo · Cash · Card

## Features
- Automatic order emails + customer auto-reply confirmation (EmailJS, free)
- SEO meta tags, social preview, and structured data for Google
- Care guide and FAQ sections
- Free custom-domain option (see `DOMAIN-SETUP.md`)

See `SETUP-GUIDE.md` for full setup steps.
