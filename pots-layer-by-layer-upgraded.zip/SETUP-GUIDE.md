# Pots Layer By Layer — Website Setup Guide
## Getting your store live on GitHub Pages (FREE, no subscriptions)

---

## STEP 1 — Create Your GitHub Repository

1. Go to **github.com** and sign in as `Cadenharrold29`
2. Click the **+** button (top right) → **New repository**
3. Name it exactly: `pots-layer-by-layer`
4. Make sure it's set to **Public**
5. Do NOT check "Add a README file"
6. Click **Create repository**

---

## STEP 2 — Upload Your Website Files

1. On the new empty repo page, click **uploading an existing file**
2. Drag and drop ALL the files and folders from this zip:
   - `index.html`
   - `css/` folder (with `style.css` inside)
   - `js/` folder (with `store.js` inside)
   - `images/` folder (add your photos here — see Step 4)
   - `robots.txt` and `sitemap.xml` (helps Google find your site)
   - `DOMAIN-SETUP.md` and `CNAME.example` (only needed once you're ready to set up a custom domain — see the bottom of this guide)
3. Scroll down, write a commit message like "Initial website upload"
4. Click **Commit changes**

---

## STEP 3 — Turn on GitHub Pages

1. In your repo, click **Settings** (top menu)
2. Scroll down to **Pages** (left sidebar)
3. Under "Source", select **Deploy from a branch**
4. Under "Branch", select **main** and **/ (root)**
5. Click **Save**
6. Wait 1-2 minutes, then your site will be live at:
   **`https://cadenharrold29.github.io/pots-layer-by-layer`**

---

## STEP 4 — Add Your Product Photos

Put your photos in the `images/` folder with these exact file names:

| File name            | What it's for            |
|----------------------|--------------------------|
| `spike-preview.jpg`  | Spike pot product card   |
| `weave-preview.jpg`  | Weave pot product card   |
| `diamond-preview.jpg`| Diamond pot product card |
| `coaster-preview.jpg`| Coaster product card     |
| `social-preview.jpg` | Shown when your link is shared on social/text (1200×630px works best) |

**Tips for great product photos:**
- Square or 4:3 ratio crops look best
- Good lighting — natural light near a window works great
- Show both bone white and olive green versions if you can
- The flyer photos you already have are perfect quality!

> If you don't have separate photos for each pot yet, the cards will show
> a styled placeholder with an icon until you add the images — it still looks great.

---

## STEP 5 — Set Up Automatic Order Emails (EmailJS)

This is better than a basic form service because it sends **two** emails automatically
every time someone checks out: an order notification to you, AND an instant
order-confirmation auto-reply to the customer — so they know their order went through
without you lifting a finger. Free plan covers 200 emails/month.

1. Go to **emailjs.com** and create a free account.
2. **Add an email service**: Email Services → Add New Service → connect your Gmail
   (`CadenHarrold29@gmail.com`). Copy the **Service ID** it gives you.
3. **Create Template #1 (to you)**: Email Templates → Create New Template.
   - To email: `CadenHarrold29@gmail.com`
   - Subject: `New Order — {{customer_name}} — {{order_total}}`
   - Content: include `{{customer_name}}`, `{{customer_email}}`, `{{customer_venmo}}`,
     `{{order_lines}}`, `{{order_total}}`, `{{notes}}` wherever you want them to appear.
   - Copy this template's **Template ID**.
4. **Create Template #2 (auto-reply to the customer)**: Create another template.
   - To email: `{{to_email}}` (this makes it dynamic per customer — important!)
   - Subject: `Your Pots Layer By Layer order is confirmed 🌿`
   - Content: a short thank-you using `{{customer_name}}`, `{{order_lines}}`, `{{order_total}}`,
     e.g. "Thanks {{customer_name}}! Your order is confirmed — I'll be in touch soon to
     arrange payment and pickup."
   - Copy this template's **Template ID**.
5. **Get your Public Key**: Account → General → copy your **Public Key**.
6. Open `js/store.js` in your GitHub repo, click the **pencil icon**, and fill in the
   four placeholders near the top:
   ```js
   const EMAILJS_PUBLIC_KEY        = 'your_public_key_here';
   const EMAILJS_SERVICE_ID        = 'your_service_id_here';
   const EMAILJS_OWNER_TEMPLATE_ID = 'your_owner_template_id_here';
   const EMAILJS_CUSTOMER_TEMPLATE_ID = 'your_customer_template_id_here';
   ```
7. Click **Commit changes**.

Until you fill these in, the checkout form automatically falls back to opening a
pre-filled email in the customer's own email app — so no order is ever lost either way.

---

## STEP 6 — Test Your Store

1. Visit your live site URL
2. Click a product, select a color, add to cart
3. Go through checkout with your own email
4. Check that you receive the order email at CadenHarrold29@gmail.com

---

## UPDATING YOUR SITE LATER

**To add new products, update prices, or change anything:**
1. Go to your GitHub repo
2. Click the file you want to edit
3. Click the pencil icon ✏️
4. Make your changes
5. Click "Commit changes" — your site updates in ~1 minute!

**To add new pot designs when ready:**
- Add a new product card in `index.html` (copy an existing one and change the text)
- Remove from the "Coming Soon" section

---

## CUSTOM DOMAIN — Including a FREE Option

See **DOMAIN-SETUP.md** in this project for full step-by-step instructions, including
how to get a completely free `potslayerbylayer.is-a.dev` domain (no cost, no credit card)
or a paid `.com` if you'd rather have one later.

---

## OTHER UPGRADES ALREADY BUILT INTO THIS VERSION

- **SEO tags** — proper page title, description, and social-share preview so links look
  good when shared on Instagram/text/Discord. Swap in a real photo at
  `images/social-preview.jpg` for the best result.
- **Google rich results** — structured product data so Google can potentially show your
  products directly in search results.
- **Care Guide section** — helps customers pick the right plant for their pot size, and
  gives Google more relevant content to index.
- **FAQ section** — answers the most common questions up front (payment, pickup, mixed
  orders, print variation) so you get fewer repeat emails.
- **Favicon** — a leaf emoji now shows in the browser tab instead of a blank page icon.
- **robots.txt / sitemap.xml** — helps search engines find and index your store.
- **Optional free analytics** — there's a commented-out line in `index.html`'s `<head>`
  for [GoatCounter](https://www.goatcounter.com) (free, no cookie banner required). Sign
  up, get your site code, uncomment the line, and swap in your code to start tracking visits.

---

## QUESTIONS?

If you get stuck on any step, you can ask Claude or Google any specific error messages.
The site is fully yours — no monthly fees, no subscriptions, nothing.

Good luck with the FFA project! 🌿
