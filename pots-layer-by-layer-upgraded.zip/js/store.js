/* =========================================
   POTS LAYER BY LAYER — Store Logic
   Cart · Checkout · Automatic Email (EmailJS)
   ========================================= */

// ── EmailJS SETUP — see SETUP-GUIDE.md "Step 5" for the 10-minute signup ──
// Free plan: 200 emails/month, no backend/server needed.
// Sends TWO emails per order automatically:
//   1) an order notification to you (Caden)
//   2) an instant order-confirmation auto-reply to the customer
const EMAILJS_PUBLIC_KEY        = 'YOUR_PUBLIC_KEY_HERE';
const EMAILJS_SERVICE_ID        = 'YOUR_SERVICE_ID_HERE';
const EMAILJS_OWNER_TEMPLATE_ID = 'YOUR_OWNER_TEMPLATE_ID_HERE';     // email that comes TO you
const EMAILJS_CUSTOMER_TEMPLATE_ID = 'YOUR_CUSTOMER_TEMPLATE_ID_HERE'; // auto-reply that goes TO the customer

if (window.emailjs && EMAILJS_PUBLIC_KEY !== 'YOUR_PUBLIC_KEY_HERE') {
  emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });
}

// ── CART STATE ──
let cart = [];

// ── ELEMENT REFS ──
const cartBtn       = document.getElementById('cartBtn');
const cartCount     = document.getElementById('cartCount');
const cartSidebar   = document.getElementById('cartSidebar');
const cartOverlay   = document.getElementById('cartOverlay');
const cartClose     = document.getElementById('cartClose');
const cartItems     = document.getElementById('cartItems');
const cartFooter    = document.getElementById('cartFooter');
const cartTotal     = document.getElementById('cartTotal');
const checkoutBtn   = document.getElementById('checkoutBtn');
const modalOverlay  = document.getElementById('modalOverlay');
const modalClose    = document.getElementById('modalClose');
const checkoutForm  = document.getElementById('checkoutForm');
const orderSuccess  = document.getElementById('orderSuccess');
const successClose  = document.getElementById('successClose');
const orderSummaryModal = document.getElementById('orderSummaryModal');

// ── OPEN / CLOSE CART ──
function openCart() {
  cartSidebar.classList.add('open');
  cartOverlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeCart() {
  cartSidebar.classList.remove('open');
  cartOverlay.classList.remove('open');
  document.body.style.overflow = '';
}

cartBtn.addEventListener('click', openCart);
cartClose.addEventListener('click', closeCart);
cartOverlay.addEventListener('click', closeCart);

// ── RENDER CART ──
function renderCart() {
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const totalQty = cart.reduce((sum, item) => sum + item.qty, 0);

  cartCount.textContent = totalQty;
  cartTotal.textContent = '$' + total.toFixed(2);

  if (cart.length === 0) {
    cartItems.innerHTML = '<p class="cart-empty">Your cart is empty.<br/>Add a pot to get started!</p>';
    cartFooter.style.display = 'none';
    return;
  }

  cartFooter.style.display = 'block';
  cartItems.innerHTML = cart.map((item, idx) => `
    <div class="cart-item">
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-meta">${item.meta} · Qty: ${item.qty}</div>
      </div>
      <div class="cart-item-price">$${(item.price * item.qty).toFixed(2)}</div>
      <button class="cart-item-remove" data-idx="${idx}" aria-label="Remove ${item.name}">✕</button>
    </div>
  `).join('');

  // Remove buttons
  cartItems.querySelectorAll('.cart-item-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      cart.splice(parseInt(btn.dataset.idx), 1);
      renderCart();
    });
  });
}

// ── ADD TO CART ──
function addToCart(name, price, color, extraCoaster, qty = 1) {
  const meta = color ? `${color}${extraCoaster ? ' + Extra Coaster' : ''}` : `Qty ${qty}`;
  const key = `${name}-${color || 'solo'}-${extraCoaster ? 'coaster' : 'no'}`;
  const total_price = extraCoaster ? price + 1.99 : price;

  const existing = cart.find(i => i.key === key);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ key, name, price: total_price, meta, qty });
  }

  renderCart();
  openCart();
}

// ── PRODUCT CARD SETUP ──
document.querySelectorAll('.product-card').forEach(card => {
  const product = card.dataset.product;

  // Color buttons
  const colorBtns = card.querySelectorAll('.color-btn:not(.coming-soon-color)');
  const selectedColorDisplay = card.querySelector('.selected-color-name');
  const addBtn = card.querySelector('.btn-add-cart');
  const coasterCheck = card.querySelector('.coaster-check');
  const qtyValue = card.querySelector('.qty-value');
  let currentQty = 1;

  colorBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      colorBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      if (selectedColorDisplay) selectedColorDisplay.textContent = btn.dataset.color;
    });
  });

  // Qty buttons (coaster standalone)
  if (qtyValue) {
    card.querySelectorAll('.qty-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.dataset.action === 'plus') currentQty = Math.min(currentQty + 1, 99);
        if (btn.dataset.action === 'minus') currentQty = Math.max(currentQty - 1, 1);
        qtyValue.textContent = currentQty;
      });
    });
  }

  // Add to cart
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      const name = addBtn.dataset.name;
      const price = parseFloat(addBtn.dataset.price);

      if (product === 'coaster') {
        addToCart(name, price, null, false, currentQty);
      } else {
        const activeColor = card.querySelector('.color-btn.active');
        const color = activeColor ? activeColor.dataset.color : 'Bone White';
        const extraCoaster = coasterCheck ? coasterCheck.checked : false;
        addToCart(name, price, color, extraCoaster);
        if (coasterCheck) coasterCheck.checked = false;
      }

      // Button feedback
      const original = addBtn.textContent;
      addBtn.textContent = '✓ Added!';
      addBtn.classList.add('added');
      setTimeout(() => {
        addBtn.textContent = original;
        addBtn.classList.remove('added');
      }, 1500);
    });
  }
});

// ── CHECKOUT ──
checkoutBtn.addEventListener('click', () => {
  closeCart();
  modalOverlay.style.display = 'flex';
  document.body.style.overflow = 'hidden';
  renderOrderSummary();
  checkoutForm.style.display = 'block';
  orderSuccess.style.display = 'none';
});

function renderOrderSummary() {
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  orderSummaryModal.innerHTML = `
    ${cart.map(item => `
      <div class="summary-item">
        <span>${item.name} (${item.meta}) × ${item.qty}</span>
        <span>$${(item.price * item.qty).toFixed(2)}</span>
      </div>
    `).join('')}
    <div class="summary-total">
      <span>Total</span>
      <span>$${total.toFixed(2)}</span>
    </div>
  `;
}

function closeModal() {
  modalOverlay.style.display = 'none';
  document.body.style.overflow = '';
}

modalClose.addEventListener('click', closeModal);
successClose.addEventListener('click', () => {
  closeModal();
  cart = [];
  renderCart();
});
modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) closeModal(); });

// ── FORM SUBMIT ──
checkoutForm.addEventListener('submit', async e => {
  e.preventDefault();
  const submitBtn = document.getElementById('submitBtn');
  submitBtn.textContent = 'Sending…';
  submitBtn.disabled = true;

  const data = new FormData(checkoutForm);
  const name    = data.get('name');
  const email   = data.get('email');
  const venmo   = data.get('venmo') || 'Not provided';
  const notes   = data.get('notes') || 'None';
  const total   = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const orderLines = cart.map(item =>
    `• ${item.name} (${item.meta}) × ${item.qty} = $${(item.price * item.qty).toFixed(2)}`
  ).join('\n');

  const message = `
NEW ORDER — Pots Layer by Layer
================================
Customer: ${name}
Email: ${email}
Venmo/Phone: ${venmo}

ORDER:
${orderLines}

TOTAL: $${total.toFixed(2)}

Notes: ${notes}

Payment: Venmo / Cash / Card
================================
  `.trim();

  const emailJsReady = window.emailjs && EMAILJS_PUBLIC_KEY !== 'YOUR_PUBLIC_KEY_HERE';

  if (emailJsReady) {
    try {
      // Email #1 — order notification to Caden
      await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_OWNER_TEMPLATE_ID, {
        customer_name: name,
        customer_email: email,
        customer_venmo: venmo,
        order_lines: orderLines,
        order_total: `$${total.toFixed(2)}`,
        notes,
        message
      });

      // Email #2 — instant auto-reply confirmation to the customer
      await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_CUSTOMER_TEMPLATE_ID, {
        customer_name: name,
        to_email: email,
        order_lines: orderLines,
        order_total: `$${total.toFixed(2)}`
      });

      checkoutForm.style.display = 'none';
      orderSuccess.style.display = 'block';
      checkoutForm.reset();
    } catch (err) {
      console.error('EmailJS error:', err);
      alert('Something went wrong sending your order. Please email CadenHarrold29@gmail.com directly, or try again.');
      submitBtn.textContent = 'Place Order';
      submitBtn.disabled = false;
    }
  } else {
    // EmailJS not configured yet — fallback so orders are never lost: open a pre-filled mailto
    const subject = encodeURIComponent(`New Order from ${name} — $${total.toFixed(2)}`);
    const body = encodeURIComponent(message);
    window.open(`mailto:CadenHarrold29@gmail.com?subject=${subject}&body=${body}`);
    checkoutForm.style.display = 'none';
    orderSuccess.style.display = 'block';
    checkoutForm.reset();
  }
});

// ── FAQ ACCORDION ──
document.querySelectorAll('.faq-item').forEach(item => {
  const btn = item.querySelector('.faq-question');
  btn.addEventListener('click', () => {
    const wasOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item.open').forEach(i => {
      i.classList.remove('open');
      i.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
    });
    if (!wasOpen) {
      item.classList.add('open');
      btn.setAttribute('aria-expanded', 'true');
    }
  });
});

// ── INIT ──
renderCart();
